<template>
  <div style="display: flex; flex-direction: column; height: 100vh;">
    <el-card class="material-card">
      <el-select v-model="value" placeholder="请选择" @change="get_table">
        <el-option
            v-for="item in data"
            :key="item.value"
            :label="item.label"
            :value="item.value">
        </el-option>
      </el-select>
      
      <el-input
          v-model="searchQuery"
          placeholder="数据综合检索"
          style="width: 300px;"
          @input="searchMaterials"
          clearable
      ></el-input>
    </el-card>

    <el-card class="material-card" style="flex: 1; display: flex; flex-direction: column; overflow: auto;">
      <el-table
          :data="filteredMaterials"
          style="width: 100%; flex: 1;"
          border
          stripe>
        <el-table-column prop="name" label="名称"></el-table-column>
        <el-table-column prop="specifications" label="规格"></el-table-column>
        <el-table-column prop="unit" label="单位"></el-table-column>
        <el-table-column prop="price" label="单价"></el-table-column>
        <el-table-column prop="type" label="类型"></el-table-column>
        <el-table-column prop="number" label="数量"></el-table-column>
        <el-table-column prop="current_time" label="时间"></el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      materials: [],
      filteredMaterials: [],
      searchQuery: '',
      data: [], // 添加日期选项数据
      value: '', // 添加选中的日期值
    };
  },

  mounted() {
    this.fetchMaterials();
    this.get_infos(); // 添加获取日期选项的方法调用
  },

  methods: {
    fetchMaterials() {
      this.$axios.get('/admin/MaterialHistory')
          .then((res) => {
            this.materials = res.data;
            this.filteredMaterials = res.data;
          });
    },

    searchMaterials() {
      const query = this.searchQuery.toLowerCase();
      this.filteredMaterials = this.searchQuery
          ? this.materials.filter(material =>
              Object.values(material).some(value =>
                String(value).toLowerCase().includes(query)
              )
            )
          : this.materials;
    },

    // 添加获取日期选项的方法
    get_infos() {
      // 修改API路径，使用与finance/table_view.vue相同的接口
      this.$axios.get('/finance/getMonthlyPlanHtml')
          .then(response => {
            console.log('获取到的日期数据:', response.data);
            this.data = response.data;
            this.value = response.data[0]?.value || '';
            this.get_table(); // 获取默认日期的数据
          })
          .catch(error => {
            console.error('获取日期信息时出错!', error);
          });
    },

    // 添加根据选择日期获取数据的方法
    get_table() {
      if (!this.value) return;
      
      // 修改为正确的API调用方式
      this.$axios.post('/admin/MaterialHistory', {month: this.value})
          .then(response => {
            console.log('根据日期获取的数据:', response.data);
            this.materials = response.data;
            this.filteredMaterials = response.data;
            this.searchMaterials(); // 应用当前的搜索条件
          })
          .catch(error => {
            console.error('获取材料历史数据时出错!', error);
          });
    },
  },
};
</script>

<style scoped>
.material-card {
  margin: 10px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
</style>
