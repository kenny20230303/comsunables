<template>
  <div style="display: flex; flex-direction: column; height: 100vh;">
    <el-card class="material-card">
      <el-select v-model="value" placeholder="请选择" @change="get_table">
        <el-option
            v-for="item in data"
            :key="item.value"
            :label="item.label"
            :value="item.value">
        </el-option>
      </el-select>

      <el-select style="padding: 0 20px" v-model="selectedTable" placeholder="选择显示的表格">
        <el-option label="日常消费" value="daily"></el-option>
        <el-option label="部门消费" value="department"></el-option>
      </el-select>

    </el-card>

    <el-card class="material-card" style="flex: 1; display: flex; flex-direction: column; overflow: auto;">
      <div v-if="loading">加载中...</div>
      <div v-else>

        <div v-if="selectedTable === 'daily'">
          <el-table :data="daily_consumption" style="width: 100%; margin-bottom: 20px;">
            <el-table-column prop="name" label="名称"></el-table-column>
            <el-table-column prop="specifications" label="规格"></el-table-column>
            <el-table-column prop="unit_price" label="单价"></el-table-column>
            <el-table-column prop="quantity" label="数量"></el-table-column>
            <el-table-column prop="total_price" label="总价" :formatter="formatPrice"></el-table-column>
          </el-table>
        </div>

        <div v-if="selectedTable === 'department'">
          <el-table :data="department_consumption" style="width: 100%;">
            <el-table-column prop="department_name" label="部门名称"></el-table-column>
            <el-table-column prop="name" label="名称"></el-table-column>
            <el-table-column prop="specifications" label="规格"></el-table-column>
            <el-table-column prop="unit_price" label="单价"></el-table-column>
            <el-table-column prop="quantity" label="数量"></el-table-column>
            <el-table-column prop="total_price" label="总价" :formatter="formatPrice"></el-table-column>
          </el-table>
          
          <!-- 添加部门消费汇总 -->
          <div class="department-summary" style="margin-top: 20px;">
            <h3>部门消费汇总</h3>
            <el-table :data="departmentSummary" style="width: 100%;">
              <el-table-column prop="department_name" label="部门名称"></el-table-column>
              <el-table-column prop="total_consumption" label="消费总计" :formatter="formatPrice"></el-table-column>
              <el-table-column label="占比">
                <template slot-scope="scope">
                  <div class="percentage-bar">
                    <div class="percentage-fill" 
                         :style="{width: scope.row.percentage + '%', backgroundColor: getDepartmentColor(scope.row.department_name)}">
                    </div>
                    <span>{{ scope.row.percentage.toFixed(2) }}%</span>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      data: [],
      value: '',
      daily_consumption: [],
      department_consumption: [],
      loading: false,
      error: null,
      selectedTable: 'daily', // 默认选择日常消费
      departmentSummary: [], // 添加部门汇总数据
    };
  },

  mounted() {
    this.get_infos();
  },

  methods: {
    get_infos() {
      this.loading = true;
      this.$axios.get('/finance/getMonthlyPlanHtml')
          .then(response => {
            this.data = response.data;
            this.value = response.data[0]?.value || ''; // 使用可选链
            this.get_table(); // 直接在这里获取表格数据
          })
          .catch(error => {
            this.error = '获取信息时出错!';
            console.error('There was an error downloading the file!', error);
          })
          .finally(() => {
            this.loading = false;
          });
    },

    get_table() {
      if (!this.value) return; // 如果没有选择值，直接返回

      this.loading = true;
      this.$axios.post('/finance/getMonthlyPlanHtml', {month: this.value})
          .then(response => {
            this.daily_consumption = response.data.daily_consumption;
            this.department_consumption = response.data.department_consumption;
            this.calculateDepartmentSummary(); // 计算部门汇总
            this.error = null; // 清除之前的错误信息
          })
          .catch(error => {
            this.error = '获取消费数据时出错!';
            console.error('There was an error downloading the file!', error);
          })
          .finally(() => {
            this.loading = false;
          });
    },
    
    formatPrice(row, column, cellValue) {
      // 如果值为空或不是数字，则返回原值
      if (cellValue === undefined || cellValue === null || isNaN(cellValue)) {
        return cellValue;
      }
      // 将值转换为数字并保留两位小数
      return Number(cellValue).toFixed(2);
    },
    
    // 计算部门消费汇总
    calculateDepartmentSummary() {
      // 创建一个Map来存储每个部门的总消费
      const departmentMap = new Map();
      
      // 计算每个部门的总消费
      this.department_consumption.forEach(item => {
        const deptName = item.department_name;
        const totalPrice = parseFloat(item.total_price) || 0;
        
        if (departmentMap.has(deptName)) {
          departmentMap.set(deptName, departmentMap.get(deptName) + totalPrice);
        } else {
          departmentMap.set(deptName, totalPrice);
        }
      });
      
      // 转换为数组格式
      const summaryArray = Array.from(departmentMap, ([department_name, total_consumption]) => ({
        department_name,
        total_consumption
      }));
      
      // 计算总消费
      const totalConsumption = summaryArray.reduce((sum, dept) => sum + dept.total_consumption, 0);
      
      // 计算每个部门的消费占比
      summaryArray.forEach(dept => {
        dept.percentage = (dept.total_consumption / totalConsumption) * 100;
      });
      
      // 按消费总额降序排序
      this.departmentSummary = summaryArray.sort((a, b) => b.total_consumption - a.total_consumption);
    },
    
    // 获取部门对应的颜色
    getDepartmentColor(departmentName) {
      // 预定义的颜色列表
      const colors = [
        '#409EFF', '#67C23A', '#E6A23C', '#F56C6C', '#909399',
        '#36A3F7', '#34BFA3', '#6B7DDF', '#F4516C', '#B37FEB'
      ];
      
      // 使用部门名称的哈希值来确定颜色索引
      const hash = departmentName.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
      return colors[hash % colors.length];
    }
  }
};
</script>

<style scoped>
.material-card {
  margin: 10px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

h3 {
  margin: 20px 0 10px;
}
/* 部门颜色设定 */
.department-summary {
  background-color: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
}

.percentage-bar {
  position: relative;
  height: 20px;
  background-color: #ebeef5;
  border-radius: 10px;
  overflow: hidden;
}

.percentage-fill {
  position: absolute;
  height: 100%;
  left: 0;
  top: 0;
  border-radius: 10px;
}

.percentage-bar span {
  position: absolute;
  width: 100%;
  text-align: center;
  color: #333;
  font-size: 12px;
  line-height: 20px;
}
</style>
